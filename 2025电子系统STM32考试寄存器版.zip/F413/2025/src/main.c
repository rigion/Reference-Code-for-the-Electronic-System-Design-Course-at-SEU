//#include "systick.h"
volatile int n=0;
volatile int flag=0;
volatile unsigned short level=0;//PWM亮度
#define LD3 *((volatile unsigned int*)0x424082b8U)
#define LD2 *((volatile unsigned int*)0x4240829cU)
#define LD1 *((volatile unsigned int*)0x42408280U)
#define ccr *((volatile unsigned short*)0x40001834U)     

extern void SystemInit(void) {
    //RCC_CR    HSE 时钟使能
    *((volatile unsigned int*)0x42470040U) = 1U;
    //RCC_CR    HSE 时钟就绪检测
    while (!(*((volatile unsigned int *)0x42470044U)));
    //FALSH ACR预取使能,4个等待周期
    *((volatile unsigned int*)0x40023C00U) = 0x00000104u;
    //AHB 域的最大频率为 100 MHz。高速 APB2 域的最大允许频率为 100 MHz。低速 APB1 域的最大允许频率为 50 MHz
    //RCC_CFGR   APB1进行2分频,设置HSE为PLL时钟源
    *((volatile unsigned int*)0x42470130U) = 1U;
    //RCC_PLLCFGR  此处认为外部晶振为8MHz 选择 HSE 振荡器时钟作为 PLL 和 PLLI2S 时钟输入 PLLM=8
    *((volatile unsigned int*)0x40023804U) = 0x28403008U; //应为96M
    //RCC 时钟控制寄存器 PLLON
    *((volatile unsigned int*)0x42470060U) = 1U;
    //等待PLL就绪   PLLRDY
    while (!(*((volatile unsigned int *)0x42470064U)));
    *((volatile unsigned int*)0x42470104U) = 1U;
    while (!((*((volatile unsigned int *)0x40023808U)) & 0x00000008));
    //初始化LED
    //RCC AHB1 外设时钟使能寄存器
    *((volatile unsigned int*)0x40023830) = 0x0000000EU;
    //GPIO 端口模式寄存器
    *((volatile unsigned int*)0x40020400U) = 0x10004001;//改过
    //按键下拉输入
    *((volatile unsigned int*)0x4002040CU) = 0x08000100;
    //中断   RCC_APB2ENR  14位
    *((volatile unsigned int*)0x424708b8U) = 1U;
    //SYSCFG_EXTICR4
    *((volatile unsigned int*)0x40013814U) = 0x00000020;
    //上升沿触发
    *((volatile unsigned int*)0x40013C08U) = 0x00002000;
    *((volatile unsigned int*)0x40013C00U) = 0x00002000;
    //EXTI15_10_IRQn= 40
    *((volatile unsigned int*)0xE000E104U) |= 0x00000100U;
    
    //UART3初始化，基地址0x40004800    PD8 TX     PD9 RX
    //RCC APB1 外设时钟使能寄存器 (RCC_APB1ENR)
    *((volatile unsigned int*)0x42470848U) = 1U;
    //PD基地址 0x40020C00     PD8复用推挽 PD9复用
    *((volatile unsigned int*)0x40020C00U) |= 0x000A0000U;
    *((volatile unsigned int*)0x40020C08U) |= 0x00030000U;//PD8高速
    *((volatile unsigned int*)0x40020C24U) = 0x00000077U;//很关键，写在输入输出设置之后位置不可变
    //配置波特率115200 
    *((volatile unsigned int*)0x40004808U) = 0x000001A1U;
    //控制寄存器 1 (USART_CR1)   使能发送与接收、中断，开启UART
    *((volatile unsigned int*)0x4000480CU) = 0x0000202CU;
    //USART3_IRQn = 39
    *((volatile unsigned int*)0xE000E104U) |= 0x00000080U;
    //*((volatile unsigned char*)0xE000E427u) = 0x10u;
}

extern void TIM7_Init() {
    //TIM7使能   RCC APB1 外设时钟使能寄存器
    *((volatile unsigned int*)0x42470814U) = 1U;
    //TIM7基地址0x40001400
    //TIM6/7 预分频器
    *((volatile unsigned short*)0x40001428) = 47999;
    //TIM6/7 自动重载寄存器
    *((volatile unsigned short*)0x4000142C) = 999;
    //中断使能
    *((volatile unsigned short*)0x4000140C) = 0x0001U;
    //TIM6/7 控制寄存器 1 计数器使能
    *((volatile unsigned short*)0x40001400) = 0x0001U;
    //NVIC      TIM7_IRQn= 55
    *((volatile unsigned int*)0xE000E104U) |= 0x00800000U;
    *((volatile unsigned int*)0xE000ED0Cu) = 0x05FA0500u;  // AIRCR
    //降低TIM7中断优先级
    *((volatile unsigned char*)0xE000E437u) = 0xF0u;
}
extern void uart3_send(volatile unsigned char*str){
    while(*str!='\0'){
        while((*((volatile unsigned int*)0x40004800U)&0x000000c0)!=0x000000C0);
        *((volatile unsigned short*)0x40004806U)=*str;
        str++;
    }
}
extern void PWM_init(){//TIM12CH1
    //使能TIM12时钟
    *((volatile unsigned int*)0x42470818U) = 1U;
    //PB14设为复用功能模式
    *((volatile unsigned int*)0x40020400U) = 0x20004001;
    *((volatile unsigned int*)0x40020408U) = 0x30000000;//高速输出
    //7.3.2图18  AF9
    *((volatile unsigned int*)0x40020424U) = 0x09000000;
    //TIM12基地址 0x40001800
    //TIM9/12 预分频器 (TIMx_PSC)
    //*((volatile unsigned short*)0x40001828U) = 47;
    //TIM9/12 自动重载寄存器 (TIMx_ARR)
    *((volatile unsigned short*)0x4000182CU) = 999;
    //TIM9/12 捕获/比较模式寄存器 1 (TIMx_CCMR1)
    *((volatile unsigned short*)0x40001818U) = 0x0068;//输出，PWM模式1，预装载
    //TIM9/12 捕获/比较使能寄存器 (TIMx_CCER)
    *((volatile unsigned short*)0x40001820U) = 0x0001;
    //TIM9/12 控制寄存器 1 (TIMx_CR1) 自动重载预装载使能 计数器使能
    *((volatile unsigned short*)0x40001800U) = 0x0081;
}


void EXTI15_10_IRQHandler(void){//没写消抖
    if((*((volatile unsigned short*)0x422782b4U))){
        switch(flag){
            case 0:{
                uart3_send((unsigned char*)"Night mode!\r\n");
                flag=1;n=10;
                *((volatile unsigned short*)0x40001424)=0;
                *((volatile unsigned short*)0x4000142C)=499;
                break;
            }
             case 1:{
                uart3_send((unsigned char*)"Normal mode!\r\n");
                flag=0;n=0;
                *((volatile unsigned short*)0x40001424)=0;
                *((volatile unsigned short*)0x4000142C)=999;
                break;
            }
             default:;
        }
    }
    *((volatile unsigned short*)0x422782b4U)=1U;
}
void USART3_IRQHandler(){
    if(*((volatile unsigned int*)0x40004800U)&0x00000020){
        if(*((volatile unsigned int*)0x40004804U)=='!'){
            uart3_send((unsigned char*)"Emergency\r\n");
            PWM_init();
            n=50;
            flag=2;
        }
    
    }
    //*((volatile unsigned int*)0x40004800U)&=0xFFFFFFDF;
}
void TIM7_IRQHandler(void){
    if(*((volatile unsigned short*)0x40001410U))
        switch(flag){
            case 0:{
                n=(n==31)?0:(n+1);
                break;
            }
            case 1:{
                n=(n==10)?11:10;
                break;
            }
            default:;
        }
        
   *((volatile unsigned short*)0x40001410U)=0;
}
int main(){
    SystemInit();
    TIM7_Init();
    uart3_send((volatile unsigned char*)"Normal mode!\r\n");
    for(;;){
        switch(n){
            case 0:case 1:case 2:case 3:case 4:   case 5:case 6:case 7:case 8:  
            case 9:{LD1=1;LD2=0;LD3=0;break;}
            case 10:case 11:case 12:case 13:case 14:
            case 15:{LD1=0;LD2=(n+1)%2;LD3=0;break;}    
            case 16:case 17:case 18:case 19:case 20:case 21:case 22:case 23:
            case 24:case 25:case 26: case 27: case 28: case 29:case 30:case 31:{LD1=0;LD2=0;LD3=1;break;}    
            default:{
                LD2=0;
                LD1=0;
                while(level<999){
                    ccr=level;
                    level++;
                    for(int i=0;i<0xFFF;i++);
                }
                while(level){
                    ccr=level;
                    level--;
                    for(int i=0;i<0xFFF;i++);
                }
            }
        
        }
        
    }
}
