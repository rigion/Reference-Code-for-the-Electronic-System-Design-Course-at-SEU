`timescale 1ns / 1ps

module led_control_tb();
	reg clk, rst;
	reg [1:0] btn;
	wire [3:0] led;
	
	initial begin
		clk = 0;
		rst = 1;
		btn = 0;
		#10;
		rst = 0;
		#20 btn = 2'b10; //模式2
		#10 btn = 0; 
		#10 btn = 2'b10; //模式3
		#10 btn = 0; 
		#80 btn = 2'b10; //模式4
		#10 btn = 0;
		#50 btn = 2'b01; //模式3
		#10 btn = 0;
	end
	
	always #5 clk=~clk; //100Mhz
	
	led_control led_control_inst0(
		.clk(clk),
		.rst(rst),
		.btn(btn),
		.led(led)
	);
	
	
endmodule
