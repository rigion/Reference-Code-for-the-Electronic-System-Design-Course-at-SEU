`timescale 1ns / 1ps
module led_control(
    input clk,
    input rst,
    input[1:0]btn,
    output[3:0]led
    );
localparam state0 = 2'b00;
localparam state1 = 2'b01;
localparam state2 = 2'b10;
localparam state3 = 2'b11;
reg [3:0]led_reg;
reg[1:0]state;
reg[1:0]cnt;
assign led=led_reg;
always@(posedge clk or posedge rst)begin
    if(rst)state<=state0;
    else if(btn[1])begin
        state<=state+1;
    end
    else if(btn[0])begin
        state<=state+3;
    end
    else state<=state;
end
always @(posedge clk or posedge rst) begin
    if(rst)cnt<=2'b00;
    else if(state==state2||state==state3)begin
        cnt<=cnt+1;
    end
    else cnt<=2'b00;
end
always@(*)begin
    case(state)
        state0:led_reg=4'b0;
        state1:led_reg=4'b1111;
        state2:led_reg=cnt[1]?4'b1111:4'b0;
        state3:led_reg=1<<cnt;
        default:led_reg=4'b0;
    endcase
end
endmodule
