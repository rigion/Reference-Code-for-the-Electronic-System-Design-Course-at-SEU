`timescale 1ns / 1ps

// 模块头在这里
// module cooker_fsm(
//     input wire        i_clk,       // 时钟信号
//     input wire        i_rstn,      // 低电平复位
//     input wire        i_set,       // 开关，低关高开
//     input wire        i_mode,      // 模式选择，0煮饭，1煮粥
//     input wire [7:0]  i_time,      // 煮粥时间设置
//     input wire        i_extra,     // 附加功能，0无锅巴，1锅巴
    
//     output reg [3:0]  o_led,       // 进度灯
//     output reg        o_buzzer,    // 蜂鸣器
//     output reg [31:0] o_print      // 打印学号
// );

module tb_cooker_fsm();

    reg         i_clk;
    reg         i_rstn;
    reg         i_set;
    reg         i_mode;
    reg [7 : 0] i_time;
    reg         i_extra;

    wire [3 : 0] o_led;
    wire         o_buzzer;
    wire [31:0]  o_print;

    initial i_clk = 0;
    always #5 i_clk = ~i_clk;

    initial begin
        i_rstn  = 0;
        i_set   = 0;
        i_mode  = 0;
        i_time  = 0;
        i_extra = 0;

        #10
        i_rstn = 1;

        #10
        i_set  = 1;
        i_mode = 0;

        #150
        i_set = 0;

        #50
        i_set  = 1;
        i_mode = 1;
        i_time = 8'd10;

        #150
        i_set  = 0;
        i_mode = 0;

        #50
        i_set   = 1;
        i_extra = 1;

        #200
        i_set = 0;
    end

    cooker_fsm cooker(
        .i_clk    (i_clk   ),
        .i_rstn   (i_rstn  ),
        .i_set    (i_set   ),
        .i_mode   (i_mode  ),
        .i_time   (i_time  ),
        .i_extra  (i_extra ),

        .o_led    (o_led   ),
        .o_buzzer (o_buzzer),
        .o_print  (o_print)
    );
endmodule
