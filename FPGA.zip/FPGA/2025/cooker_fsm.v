`timescale 1ns / 1ps
module cooker_fsm(
    input wire        i_clk,       // ʱ���ź�
    input wire        i_rstn,      // �͵�ƽ��λ
    input wire        i_set,       // ���أ��͹ظ߿�
    input wire        i_mode,      // ģʽѡ��0�󷹣�1����
    input wire [7:0]  i_time,      // ����ʱ������
    input wire        i_extra,     // ���ӹ��ܣ�0�޹��ͣ�1����
    
    output reg [3:0]  o_led,       // ���ȵ�
    output reg        o_buzzer,    // ������
    output reg [31:0] o_print      // ��ӡѧ��
);
reg[1:0]state;
reg [7:0]cnt;
reg [3:0]water_led;
localparam IDLE = 2'b00;
localparam RICE = 2'b01;
localparam PORRIDGE = 2'b10;
localparam INSULATION = 2'b11;
always @(posedge i_clk or negedge i_rstn) begin
    if(!i_rstn)begin
        state<=IDLE;
        cnt<=0;
        water_led<=4'b1000;
    end
    else begin
        case(state)
            IDLE:begin
                cnt<=0;
                water_led<=4'b1000;
                if(i_set&&i_mode)state<=PORRIDGE;
                else if(i_set&&(!i_mode))state<=RICE;
            end
            RICE:begin
                cnt<=cnt+1;
                if(!i_extra)begin
                    if(cnt==8'b00001000)begin
                        state<=INSULATION;
                        cnt<=0;
                    end
                end
                else begin
                    if(cnt==8'b00010000)begin
                        state<=INSULATION;
                        cnt<=0;
                    end
                end
            end
            PORRIDGE:begin
                cnt<=cnt+1;
                water_led<={water_led[0],water_led[3:1]};
                if(cnt==i_time)begin 
                    state<=INSULATION;
                    cnt<=0;
                end
            end
            INSULATION:begin
                cnt<=cnt>=5?cnt:cnt+1;
                if(!i_set)state<=IDLE;
            end
            default:begin
                state<=state;
                cnt<=cnt;
                water_led<=4'b1000;
            end
        endcase
    end
end
always @(*) begin
    if(!i_rstn)begin
        o_led=0; 
        o_buzzer=0;
        o_print=0; 
    end
    else begin
        case(state)
            IDLE:begin
                o_led=0;
                o_buzzer=0;
                o_print=0;
            end
            RICE:begin
                if((!i_extra)&&cnt[0]==0&&cnt!=0)o_led={1'b1,o_led[3:1]};
                else if((i_extra)&&cnt[1:0]==0&&cnt!=0)o_led={1'b1,o_led[3:1]};
            end
            PORRIDGE:begin
                o_led=water_led;
            end
            INSULATION:begin
                o_led=4'b1111;
                o_print={4'd0,4'd6,4'd0,4'd2,4'd3,4'd3,4'd0,4'd4};
                if(cnt<7'd2)o_buzzer=1;
                else o_buzzer=0;
            end
            default:begin
                o_led=o_led;
                o_print=o_print;
                o_buzzer=o_buzzer;
            end
        endcase
    end
end
endmodule
