`timescale 1ns / 1ps
//我也不敢确认这个程序是对的，仅供参考
//尤其是灯的控制，到底是进入状态的瞬间就亮还是进入状态等一个时钟再亮，题目都没说清楚
module Boot_FSM(input i_clk, 
input i_rstn, 
input i_fs_err, //I(1), filesystem error flag
input i_driver_err, //I(1), driver load error flag
input i_btn, //I(1), button
output [1:0] o_led, //O(2), led status
output [7:0] o_msg, //O(8), output message
output o_buzzer); //O(1), buzzer signal
reg[7:0]state;
reg[1:0]led;
reg buzzer;
reg[7:0]msg;
assign o_msg=msg;
assign o_buzzer=buzzer;
assign o_led=led;
localparam INIT = 8'b00000001;
localparam CHECK_FS = 8'b00000010;
localparam FS_ERR = 8'b00000100;
localparam FS_OK = 8'b00001000;
localparam LD_DRIVER = 8'b00010000;
localparam DRIVER_OK = 8'b00100000;
localparam DRIVER_ERR = 8'b01000000;
localparam BOOT_OK = 8'b10000000;
always @(posedge i_clk or negedge i_rstn) begin
    if(!i_rstn)begin
        state<=INIT;
        led<=2'b0;
        buzzer<=1'b0;
        msg<=8'b0;
    end
    else begin
        case(state)
            INIT:begin
                state<=CHECK_FS;
                buzzer<=1'b0;
                led<=2'b0;
                msg<=8'b0;
            end
            CHECK_FS:state<=(i_fs_err)?FS_ERR:FS_OK;
            FS_OK:begin
                state<=LD_DRIVER;
                led[0]<=1'b1;
            end
            FS_ERR:begin
                buzzer<=1'b1;
                state<=(i_btn)?INIT:state;
            end
            LD_DRIVER:state<=(i_driver_err)?DRIVER_ERR:DRIVER_OK;
            DRIVER_OK:begin
                state<=BOOT_OK;
                led[1]<=1'b1;
            end
            DRIVER_ERR:begin
                state<=(i_btn)?INIT:state;
                buzzer<=1'b1;
            end
            BOOT_OK:begin
                state<=(i_btn)?INIT:state;
                msg<={4'd0,4'd6};
            end
            default:state<=INIT;
        endcase
    end
end
endmodule
