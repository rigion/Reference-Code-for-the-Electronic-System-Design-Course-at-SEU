`timescale 1ns / 1ps

module tb_Boot_FSM();
    reg i_clk        = 0;
    reg i_rstn       = 0;
    reg i_fs_err     = 0;
    reg i_driver_err = 0;
    reg i_rst_btn    = 0;
    wire [1:0] o_led;
    wire [7:0] o_msg;
    wire o_buzzer;
    
    //clock
    always #5 i_clk <= ~i_clk;
    initial begin
        i_clk        <= 1'b0;
        i_rstn       <= 1'b0;
        i_fs_err     <= 1'b0;
        i_driver_err <= 1'b0;
        i_rst_btn    <= 1'b0;
        
    @(posedge i_clk)i_rstn <= 1'b1;
    
    
    @(posedge i_clk)i_fs_err <= 1'b1;
    repeat (10) @(posedge i_clk);
    @(posedge i_clk)i_fs_err <= 1'b0;
    //rst btn press
    @(posedge i_clk)i_rst_btn <= 1'b1;
    @(posedge i_clk)i_rst_btn <= 1'b0;
    //check the buzzer and led
    
    repeat (10) @(posedge i_clk);
    //rst btn press
    @(posedge i_clk)i_rst_btn <= 1'b1;
    @(posedge i_clk)i_rst_btn <= 1'b0;
    
    @(posedge i_clk)i_driver_err <= 1'b1;
    repeat (10) @(posedge i_clk);
    @(posedge i_clk)i_driver_err <= 1'b0;
    //rst btn press
    @(posedge i_clk)i_rst_btn <= 1'b1;
    @(posedge i_clk)i_rst_btn <= 1'b0;
    //check the buzzer and led
    repeat (10) @(posedge i_clk);
    
    //no error
    @(posedge i_clk)begin
    i_fs_err     <= 1'b0;
    i_driver_err <= 1'b0;
    end
    end
    
    
    
    Boot_FSM inst_Boot_FSM(
    .i_clk(i_clk),
    .i_rstn(i_rstn),
    .i_fs_err(i_fs_err),
    .i_driver_err(i_driver_err),
    .i_btn(i_rst_btn),
    .o_led(o_led),
    .o_msg(o_msg),
    .o_buzzer(o_buzzer)
    );
endmodule
